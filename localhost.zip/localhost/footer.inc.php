<div class="footer">
            <h2>Мы пробежали основы PHP!</h2>
        </div>