

<?php 
 $p = 'Здравствуйте!';
?>

<?php 
 $name = 'Андрей';
 $surname = 'Т';
 $city = 'Питер';
 $age = 57;
?>


<?php
include 'main.php';
?>

