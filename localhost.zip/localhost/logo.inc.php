    
                <div class="logo"> 
                <img src="img/photo202_2.jpg" alt="php">
                </div>                                                 
        