            <nav>
                <ul>
                    <li><a href="#"> Важно </a></li>
                    <li><a href="#"> Не важно </a></li>
                    <li><a href="#"> О нас </a></li>
                </ul>    
            </nav>